package ae.etisalat.qa.bill.compare.regressionexecutor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegressionExecutorApplicationTests {

    @Test
    void contextLoads() {
    }

}
